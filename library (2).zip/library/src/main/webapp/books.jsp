<%-- 
    Document   : books
    Created on : 7 Apr 2026, 9:41:04 am
    Author     : MSIS
--%>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*, model.Book" %>

<h2>Available Books</h2>

    <table border="1">
    <tr>
        <th>ID</th><th>Title</th><th>Author</th><th>Copies</th>
    </tr>

    <%
    List<Book> list = (List<Book>)request.getAttribute("books");
    for(Book b : list) {
    %>
    <tr>
    <td><%=b.getBookId()%></td>
    <td><%=b.getTitle()%></td>
    <td><%=b.getAuthor()%></td>
    <td><%=b.getAvailableCopies()%></td>
    </tr>
    <% } %>
    </table>
    <br><br>
<a href="index.html"> Back to Main Menu</a>