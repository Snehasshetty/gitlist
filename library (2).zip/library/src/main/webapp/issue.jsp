<%-- 
    Document   : issue
    Created on : 7 Apr 2026, 9:42:27 am
    Author     : MSIS
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Issue Book</h2>

        <form action="issueBook" method="post">
            Book ID: <input type="text" name="bookId"><br>
            Member ID: <input type="text" name="memberId"><br>
            <input type="submit" value="Issue">
            <%
            String msg = (String) request.getAttribute("message");
            if (msg != null) {
            %>
                <p style="color:red;"><%= msg %></p>
            <%
                }
            %>
        </form>
        <br><br>
        <form action="index.html">
            <input type="submit" value="Back to Main Menu">
        </form>
    </body>
</html>
