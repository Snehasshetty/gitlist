<%-- 
    Document   : return
    Created on : 7 Apr 2026, 9:42:47 am
    Author     : MSIS
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Return Book</h2>

    <form action="returnBook" method="post">
    Issue ID: <input type="text" name="issueId"><br>
    Book ID: <input type="text" name="bookId"><br>
    <input type="submit" value="Return">
    </form>
    </body>
    <br><br>
<a href="index.html">Back to Main Menu</a>
</html>
