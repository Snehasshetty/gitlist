/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.logging.Logger;
import model.IssueDAO;
import model.LoggerUtil;


/**
 *
 * @author MSIS
 
@WebServlet("/issueBook")
public class IssueBookServlet extends HttpServlet {
    private static final Logger logger = LoggerUtil.getLogger();
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        try {
            int bookId = Integer.parseInt(req.getParameter("bookId"));
            int memberId = Integer.parseInt(req.getParameter("memberId"));

            new IssueDAO().issueBook(bookId, memberId);
            logger.info("ISSUE_BOOK SUCCESS: BookID=" + bookId + ", MemberID=" + memberId);

            res.sendRedirect("books");
        } catch(Exception e) {
            logger.severe("ISSUE_BOOK FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}*/
@WebServlet("/issueBook")
public class IssueBookServlet extends HttpServlet {
    private static final Logger logger = LoggerUtil.getLogger();

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        try {
            int bookId = Integer.parseInt(req.getParameter("bookId"));
            int memberId = Integer.parseInt(req.getParameter("memberId"));

            new IssueDAO().issueBook(bookId, memberId);

            logger.info("ISSUE_BOOK SUCCESS: BookID=" + bookId + ", MemberID=" + memberId);

            res.sendRedirect("books");

        } catch(Exception e) {

            logger.severe("ISSUE_BOOK FAILED: " + e.getMessage());

            // ✅ Send error message to JSP
            req.setAttribute("message", e.getMessage());

            req.getRequestDispatcher("issue.jsp").forward(req, res);
        }
    }
}