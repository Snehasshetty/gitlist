/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.logging.Logger;
import model.BookDAO;
import model.LoggerUtil;

/**
 *
 * @author MSIS
 */

@WebServlet("/books")
public class BookServlet extends HttpServlet {
    private static final Logger logger = LoggerUtil.getLogger();
    
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {
        logger.info("TEST LOG ENTRY");
        System.out.println("Logger executed");

        try {
            req.setAttribute("books", new BookDAO().getAvailableBooks());
            req.getRequestDispatcher("books.jsp").forward(req, res);
            logger.info("VIEW_BOOKS: User viewed available books");
        } catch(Exception e) {
            logger.severe("VIEW_BOOKS FAILED: User not able to view available books");
            e.printStackTrace();
        }
    }
}