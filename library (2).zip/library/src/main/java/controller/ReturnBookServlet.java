/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.logging.Logger;
import model.IssueDAO;
import model.LoggerUtil;

/**
 *
 * @author MSIS
 
@WebServlet("/returnBook")
public class ReturnBookServlet extends HttpServlet {
    private static final Logger logger = LoggerUtil.getLogger();
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        try {
            int issueId = Integer.parseInt(req.getParameter("issueId"));
            int bookId = Integer.parseInt(req.getParameter("bookId"));

            new IssueDAO().returnBook(issueId, bookId);
            logger.info("RETURN_BOOK SUCCESS: IssueID=" + issueId);

            res.sendRedirect("books");
        } catch(Exception e) {
            logger.severe("RETURN_BOOK FAILED");
            e.printStackTrace();
        }
    }
}
*/
@WebServlet("/returnBook")
public class ReturnBookServlet extends HttpServlet {

    private static final Logger logger = LoggerUtil.getLogger();

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        try {
            int issueId = Integer.parseInt(req.getParameter("issueId"));
            int bookId = Integer.parseInt(req.getParameter("bookId"));

            new IssueDAO().returnBook(issueId, bookId);

            logger.info("RETURN_BOOK SUCCESS: IssueID=" + issueId);

            res.sendRedirect("books");

        } catch(Exception e) {
            logger.severe("RETURN_BOOK FAILED: " + e.getMessage());

            req.setAttribute("message", e.getMessage());
            req.getRequestDispatcher("return.jsp").forward(req, res);
        }
    }
}