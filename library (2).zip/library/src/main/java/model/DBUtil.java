/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Logger;

/**
 *
 * @author MSIS
 */
public class DBUtil {
    private static final Logger logger = Logger.getLogger("Library");
    public static Connection getConnection() throws Exception {
        logger.info("Establishing DB Connection..");
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/library_db",
            "sheetal",
            "pass"
        );
    }
    
}
