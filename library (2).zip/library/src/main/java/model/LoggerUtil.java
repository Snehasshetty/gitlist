/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.IOException;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 *
 * @author MSIS
 */
public class LoggerUtil {
    private static final Logger logger = Logger.getLogger("Library");
    static{
        try{
            String path = "D:/logs/library.log";
            FileHandler filehandler =new FileHandler(path,true);
            filehandler.setFormatter(new SimpleFormatter());
            logger.addHandler(filehandler);
            logger.setLevel(Level.ALL);
        } catch (IOException e) {
           e.printStackTrace();
        }
    }
   public static Logger getLogger(){
       return logger;
   }
    }
        
    

