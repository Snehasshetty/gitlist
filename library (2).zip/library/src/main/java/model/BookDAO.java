/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.*;
import java.util.*;
import java.util.logging.Logger;


/**
 *
 * @author MSIS
 */
public class BookDAO {
 
     public List<Book> getAvailableBooks() throws Exception {
        List<Book> list = new ArrayList<>();
        Connection con = DBUtil.getConnection();

        String sql = "SELECT * FROM book WHERE available_copies > 0";
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while(rs.next()) {
            Book b = new Book();
            b.setBookId(rs.getInt("book_id"));
            b.setTitle(rs.getString("title"));
            b.setAuthor(rs.getString("author"));
            b.setPublisher(rs.getString("publisher"));
            b.setAvailableCopies(rs.getInt("available_copies"));
            list.add(b);
        }
 
        return list;
    }

    public void decreaseCopies(int bookId) throws Exception {
        Connection con = DBUtil.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "UPDATE book SET available_copies = available_copies - 1 WHERE book_id=?"
        );
        ps.setInt(1, bookId);
        ps.executeUpdate();
    }

    public void increaseCopies(int bookId) throws Exception {
        Connection con = DBUtil.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "UPDATE book SET available_copies = available_copies + 1 WHERE book_id=?"
        );
        ps.setInt(1, bookId);
        ps.executeUpdate();
    }
    
}
