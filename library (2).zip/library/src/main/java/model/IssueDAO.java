/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.*;
import java.util.logging.Logger;

/**
 *
 * @author MSIS
 */
public class IssueDAO {
    private static final Logger logger = Logger.getLogger("Library");
    /*  public void issueBook(int bookId, int memberId) throws Exception {
        Connection con = DBUtil.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO issue(book_id, member_id, issue_date) VALUES (?, ?, CURDATE())"
        );
        ps.setInt(1, bookId);
        ps.setInt(2, memberId);
        ps.executeUpdate();

        new BookDAO().decreaseCopies(bookId);
       logger.info("Book Issued: BookID=" + bookId + ", MemberID=" + memberId);
    }

    public void returnBook(int issueId, int bookId) throws Exception {
        Connection con = DBUtil.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "UPDATE issue SET return_date = CURDATE() WHERE issue_id=?"
        );
        ps.setInt(1, issueId);
        ps.executeUpdate();

        new BookDAO().increaseCopies(bookId);

        logger.info("Book Returned: IssueID=" + issueId);
    }*/
    public void issueBook(int bookId, int memberId) throws Exception {
        Connection con = DBUtil.getConnection();

        try {
            // ✅ Check available copies
            PreparedStatement checkStmt = con.prepareStatement(
                "SELECT available_copies FROM book WHERE book_id=?"
            );
            checkStmt.setInt(1, bookId);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                logger.severe("ISSUE_BOOK FAILED: Invalid BookID=" + bookId);
                throw new Exception("Invalid Book ID");
            }

            int copies = rs.getInt("available_copies");

            // ❗ MAIN CONDITION
            if (copies <= 0) {
                logger.warning("ISSUE_BOOK FAILED: No copies available for BookID=" + bookId);
                throw new Exception("Book not available (no copies left)");
            }

            // ✅ Insert issue record
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO issue(book_id, member_id, issue_date) VALUES (?, ?, CURDATE())"
            );
            ps.setInt(1, bookId);
            ps.setInt(2, memberId);
            ps.executeUpdate();

            // ✅ Decrease copies
            new BookDAO().decreaseCopies(bookId);

            logger.info("ISSUE_BOOK SUCCESS: BookID=" + bookId + ", MemberID=" + memberId);

        } catch (Exception e) {
            logger.severe("ISSUE_BOOK FAILED: " + e.getMessage());
            throw e;
        } finally {
            con.close();
        }
    }

    public void returnBook(int issueId, int bookId) throws Exception {

        Connection con = DBUtil.getConnection();

        try {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE issue SET return_date = CURDATE() WHERE issue_id=?"
            );
            ps.setInt(1, issueId);

            int rows = ps.executeUpdate();

            if (rows == 0) {
                logger.severe("RETURN_BOOK FAILED: No record found for IssueID=" + issueId);
                throw new Exception("Invalid Issue ID");
            }

            new BookDAO().increaseCopies(bookId);

            logger.info("RETURN_BOOK SUCCESS: IssueID=" + issueId);

        } catch (Exception e) {
            logger.severe("RETURN_BOOK FAILED: " + e.getMessage());
            throw e;
        } finally {
            con.close();
        }
    }
}
