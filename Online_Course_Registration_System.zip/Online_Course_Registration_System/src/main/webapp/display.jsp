<%-- 
    Document   : display
    Created on : 31 Mar 2026, 10:32:28?am
    Author     : MSIS
--%>
<%--
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Hello World!</h1>
    </body>
    
</html>
--%>

<%@ page import="java.util.*, model.Course" %>

<!DOCTYPE html>
<html>
<head>
    <title>Enrolled Courses</title>
</head>
<body>

<h2>Enrolled Courses</h2>

<table border="1">
<tr>
    <th>Course Name</th>
    <th>Duration</th>
    <th>Fee</th>
</tr>

<%
ArrayList<Course> list = (ArrayList<Course>) request.getAttribute("courses");

if(list != null && list.size() > 0) {
    for(Course c : list) {
%>
<tr>
    <td><%= c.getCourse_name() %></td>
    <td><%= c.getDuration() %></td>
    <td>?<%= c.getFee() %></td>
</tr>
<%
    }
} else {
%>
<tr>
    <td colspan="3">No courses found for this Student ID</td>
</tr>
<%
}
%>

</table>

<br>
<button onclick="window.location.href='index.html'">Back to Home</button>

</body>
</html>