<%-- 
    Document   : register
    Created on : 31 Mar 2026, 10:32:14 am
    Author     : MSIS
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Register Here!!!</h1>
        <form action="register" method="post">
            Student ID: <input type="text" name="student_id"><br>
            Course ID: <input type="text" name="course_id"><br>
            <input type="submit" value="Enroll">
        </form>
        
        <br>

            <!-- Back Button -->
            <button onclick="window.location.href='index.html'">Back</button>
    </body>
</html>
