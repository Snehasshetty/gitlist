<%-- 
    Document   : search
    Created on : 31 Mar 2026, 11:22:22?am
    Author     : MSIS
--%>

<!DOCTYPE html>
<html>
<head>
    <title>Search Student</title>
</head>
<body>

<h2>Enter Student ID</h2>

<form action="display" method="get">
    Student ID: <input type="text" name="student_id" required>
    <input type="submit" value="Show Courses">
</form>

</body>
</html>
