/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import model.Course;
import util.LoggerUtil;
/**
 *
 * @author MSIS
 */
public class EnrollmentDAO {

    // Register course
    public void enroll(int student_id, int course_id) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO Enrollment(student_id, course_id, enroll_date) VALUES (?, ?, CURDATE())"
            );
            ps.setInt(1, student_id);
            ps.setInt(2, course_id);

            ps.executeUpdate();
            LoggerUtil.log("Student " + student_id + " enrolled in course " + course_id);

        } catch(Exception e) {
            LoggerUtil.log("Error in enrollment: " + e.getMessage());
        }
    }

    // Display enrolled courses
    public ArrayList<Course> getCourses(int student_id) {
        ArrayList<Course> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "SELECT c.* FROM Course c JOIN Enrollment e ON c.course_id = e.course_id WHERE e.student_id=?"
            );
            ps.setInt(1, student_id);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                Course c = new Course();
                c.setCourse_id(rs.getInt(1));
                c.setCourse_name(rs.getString(2));
                c.setDuration(rs.getString(3));
                c.setFee(rs.getDouble(4));

                list.add(c);
            }

            LoggerUtil.log("Fetched courses for student " + student_id);

        } catch(Exception e) {
            LoggerUtil.log("Error fetching courses: " + e.getMessage());
        }
        return list;
    }
}