/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import model.Course;

/**
 *
 * @author MSIS
 */
public class CourseDAO {

    Connection con;

    // Constructor to establish connection
    public CourseDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/online_course_db",
                "deepti",
                "deepti@123"
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 🔹 Get all courses
    public ArrayList<Course> getAllCourses() {

        ArrayList<Course> list = new ArrayList<>();

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Course");

            while (rs.next()) {
                Course c = new Course();

                c.setCourse_id(rs.getInt("course_id"));
                c.setCourse_name(rs.getString("course_name"));
                c.setDuration(rs.getString("duration"));
                c.setFee(rs.getInt("fee"));

                list.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // 🔹 Get course by ID
    public Course getCourseById(int id) {

        Course c = null;

        try {
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM Course WHERE course_id=?"
            );

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                c = new Course();

                c.setCourse_id(rs.getInt("course_id"));
                c.setCourse_name(rs.getString("course_name"));
                c.setDuration(rs.getString("duration"));
                c.setFee(rs.getInt("fee"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }
}