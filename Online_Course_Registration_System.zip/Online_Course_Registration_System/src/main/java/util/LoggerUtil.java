/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;
/**
 *
 * @author MSIS
 */
public class LoggerUtil {

    public static void log(String message) {
        try {
            FileWriter fw = new FileWriter("app_log.txt", true);
            PrintWriter pw = new PrintWriter(fw);

            pw.println(new Date() + " : " + message);

            pw.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}