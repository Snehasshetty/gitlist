/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import dao.EnrollmentDAO;
/**
 *
 * @author MSIS
 */
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int student_id = Integer.parseInt(req.getParameter("student_id"));
        int course_id = Integer.parseInt(req.getParameter("course_id"));

        EnrollmentDAO dao = new EnrollmentDAO();
        dao.enroll(student_id, course_id);

        res.sendRedirect("display?student_id=" + student_id);
    }
}