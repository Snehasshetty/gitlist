/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;
import dao.EnrollmentDAO;
import model.Course;
/**
 *
 * @author MSIS
 */
public class DisplayServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int student_id = Integer.parseInt(req.getParameter("student_id"));

        EnrollmentDAO dao = new EnrollmentDAO();
        ArrayList<Course> list = dao.getCourses(student_id);

        req.setAttribute("courses", list);
        RequestDispatcher rd = req.getRequestDispatcher("display.jsp");
        rd.forward(req, res);
    }
}